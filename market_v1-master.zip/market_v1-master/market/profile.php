<?php



?>

<html>

	<head><title>Profile</title></head>
	<body>
		<table border="1" align="center">
			<tr><td colspan="2" align="center"></td></tr>
			<tr><td>First name:</td><td></td></tr>
			<tr><td>Lastname name:</td><td></td></tr>
			<tr><td>Email:</td><td></td></tr>
		</table>
		<br><center><input type="Submit" value="Edit profile"></center>
	</body>
</html>